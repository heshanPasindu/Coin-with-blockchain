import { useState } from "react";
import { ethers } from "ethers";
import CounterContract from "../artifacts/contracts/Counter.sol/Counter.json";

const contractAddress = "0xb891a4ca2d12B1D5caF3316Ba1B124eDDe031cF1";
const abi = CounterContract.abi;

export default function App() {
  // state
  const [connectButton, setConnectButton] = useState("Connect");
  const [count, setCount] = useState("");

  const handleConnect = async () => {
    if (typeof window.ethereum != "undefined") {
      await window.ethereum.request({ method: "eth_requestAccounts" });
      setConnectButton("Connected!");
    } else {
      setConnectButton("Please install Metamask");
    }
  };

  const getCount = async () => {
    if (typeof window.ethereum != "undefined") {
      // connect to blockchain using provider
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      // interacting user account/signer - current metamask account
      const signer = provider.getSigner();
      // interacting contract abi and address
      const contract = new ethers.Contract(contractAddress, abi, signer);
      try {
        const data = await contract.get();
        console.log("data: ", data.toString());
        setCount(data.toString());
      } catch (err) {
        console.log(err);
      }
    }
  };

  const handleInc = async () => {
    if (typeof window.ethereum != "undefined") {
      // connect to blockchain using provider
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      // interacting user account/signer - current metamask account
      const signer = provider.getSigner();
      // interacting contract abi and address
      const contract = new ethers.Contract(contractAddress, abi, signer);
      try {
        const tx = await contract.inc();
        await tx.wait();
        getCount();
      } catch (err) {
        console.log(err);
      }
    }
  };

  const handleDec = async () => {
    if (typeof window.ethereum != "undefined") {
      // connect to blockchain using provider
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      // interacting user account/signer - current metamask account
      const signer = provider.getSigner();
      // interacting contract abi and address
      const contract = new ethers.Contract(contractAddress, abi, signer);
      try {
        const tx = await contract.dec();
        await tx.wait();
        getCount();
      } catch (err) {
        console.log(err);
      }
    }
  };

  return (
    <div>
      <button onClick={handleConnect}>{connectButton}</button>
      <button onClick={getCount}>Get count</button>
      <button onClick={handleInc}>Increment count</button>
      <button onClick={handleDec}>Decrement count</button>
      <hr />
      <h1>Count: {count}</h1>
    </div>
  );
}
