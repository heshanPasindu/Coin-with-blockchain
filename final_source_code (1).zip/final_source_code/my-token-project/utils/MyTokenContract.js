import { ethers } from "ethers";
import MyToken from "../data/MyToken.json";

const provider = new ethers.providers.JsonRpcProvider(
  process.env.HARDHAT_RPC_URL
);

export const signer = provider.getSigner();
export const contract = new ethers.Contract(
  MyToken.address,
  MyToken.abi,
  provider
);
