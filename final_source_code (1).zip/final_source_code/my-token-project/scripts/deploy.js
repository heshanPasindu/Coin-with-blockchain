const hre = require("hardhat");
const fs = require("fs");

async function main() {
  // get the contract
  const MyToken = await hre.ethers.getContractFactory("MyToken");
  // deploy the contract
  const myToken = await MyToken.deploy("MyToken", "MYT");
  console.log("Contract deployed to address:", myToken.address);

  // generate abi and contract address for frontend
  const abi = myToken.interface.format("json");
  const address = myToken.address;
  const contractData = { abi, address };
  const filePath = "./data/MyToken.json";
  fs.writeFileSync(filePath, JSON.stringify(contractData));
  console.log("Contract data written to file:", filePath);

  // get the transaction receipt
  const receipt = await myToken.deployTransaction.wait();
  console.log("Deployed by address: ", receipt.from);
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
