import { useState, useEffect } from "react";
import { useMoralis } from "react-moralis";
import { contract, signer } from "../utils/MyTokenContract";
import { ethers } from "ethers";
import toast from "react-hot-toast";

export default function TransferToken() {
  const [address, setAddress] = useState("");
  const [amount, setAmount] = useState(0);
  const [loading, setLoading] = useState(false);

  const { account } = useMoralis();

  const handleTransfer = async () => {
    try {
      setLoading(true);
      // console.log("handleTransfer");
      const decimals = await contract.decimals();
      const formattedAmount = ethers.utils.parseUnits(amount, decimals);
      // send the transaction using the current account
      console.log("SIGNER => ", signer, "ACCOUNT => ", account);
      const tx = await contract
        .connect(signer)
        .transfer(address, formattedAmount);
      await tx.wait();
      toast.success("Token transferred successfully");
      setLoading(false);
      setAddress("");
      setAmount(0);
      window.location.reload();
    } catch (error) {
      console.log(error);
      toast.error("Error transferring token");
      setLoading(false);
    }
  };

  return (
    <div className="text-center bg-light p-5 m-5">
      <h1>Transfer MYT</h1>

      <input
        type="text"
        className="form-control p-3 m-3"
        placeholder="Wallet address"
        value={address}
        onChange={(event) => setAddress(event.target.value)}
      />

      <input
        type="number"
        className="form-control p-3 m-3"
        placeholder="Amount of token"
        value={amount}
        onChange={(event) => setAmount(event.target.value)}
      />

      <button
        onClick={handleTransfer}
        className="btn col-3 btn-secondary p-3 m-3"
        disabled={loading}
      >
        {loading ? "Loading" : "Transfer"}
      </button>
    </div>
  );
}
