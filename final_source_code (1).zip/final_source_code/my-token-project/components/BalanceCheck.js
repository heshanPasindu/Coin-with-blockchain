import { useState } from "react";
import { contract, signer } from "../utils/MyTokenContract";
import { ethers } from "ethers";

export default function TransferToken() {
  const [address, setAddress] = useState("");
  const [balance, setBalance] = useState("");
  const [loading, setLoading] = useState(false);

  const handleBalanceCheck = async () => {
    try {
      setLoading(true);
      const balance = await contract.balanceOf(address);
      const formattedBalance = ethers.utils.formatEther(balance);
      setBalance(formattedBalance);
      setLoading(false);
    } catch (error) {
      console.log(error);
      toast.error("Error transferring token");
      setLoading(false);
    }
  };

  return (
    <div className="text-center bg-light p-5 m-5">
      <h1>MYT Balance Check</h1>

      {balance !== "" ? (
        <h1 className="mb-5 text-primary">{balance} MYT</h1>
      ) : (
        ""
      )}

      <input
        type="text"
        className="form-control p-3 m-3"
        placeholder="Wallet address"
        value={address}
        onChange={(event) => setAddress(event.target.value)}
      />

      <button
        onClick={handleBalanceCheck}
        className="btn col-3 btn-secondary p-3 m-3"
        disabled={loading || !address}
      >
        {loading ? "Loading" : "Submit"}
      </button>
    </div>
  );
}
