import { useState, useEffect } from "react";
import { contract } from "../utils/MyTokenContract";
import { ethers } from "ethers";

export default function App() {
  // state
  const [tokenName, setTokenName] = useState("");
  const [tokenSymbol, setTokenSymbol] = useState("");
  const [tokenTotalSupply, setTokenTotalSupply] = useState("");

  useEffect(() => {
    getContractInfo();
  }, []);

  const getContractInfo = async () => {
    const name = await contract.name();
    setTokenName(name);

    const symbol = await contract.symbol();
    setTokenSymbol(symbol);

    const supply = await contract.totalSupply();
    setTokenTotalSupply(ethers.utils.formatUnits(supply, 18));
  };

  return (
    <div className="container">
      <div className="m-5">
        <p className="alert alert-light">Token name: {tokenName}</p>
        <p className="alert alert-light">Token symbol: {tokenSymbol}</p>
        <p className="alert alert-light">
          Token total supply: {tokenTotalSupply}
        </p>
      </div>
    </div>
  );
}
