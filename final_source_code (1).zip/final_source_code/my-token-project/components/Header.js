import { ConnectButton } from "web3uikit";
import { useState, useEffect } from "react";
import { useMoralis } from "react-moralis";
import { contract } from "../utils/MyTokenContract";
import { ethers } from "ethers";

export default function Header() {
  const [userBalance, setUserBalance] = useState(0);

  // const { enableWeb3, account } = useMoralis();
  const { isWeb3Enabled, account } = useMoralis();

  useEffect(() => {
    if (isWeb3Enabled && account) {
      const getBalance = async () => {
        // const userAddress = await signer.getAddress();
        // console.log("user address => ", account);
        const balance = await contract.balanceOf(account);
        const formattedBalance = ethers.utils.formatEther(balance);
        setUserBalance(formattedBalance);
      };
      // execute the function
      getBalance();
    } else {
      console.log("Web3 not enabled", isWeb3Enabled);
    }
  }, [isWeb3Enabled, account]);

  return (
    <div>
      <div className="d-flex justify-content-between">
        <ConnectButton />
        <p>
          <span className="badge bg-danger">{userBalance} MYT</span>
        </p>
      </div>
      {/* {account ? (
        <div>
          Connected to {account.slice(0, 6)}...{account.slice(-4)}
        </div>
      ) : (
        <button
          onClick={async () => {
            await enableWeb3();
          }}
        >
          Enable Web3
        </button>
      )} */}
    </div>
  );
}
