import Header from "../components/Header";
import TokenInfo from "../components/TokenInfo";
import TransferToken from "../components/TransferToken";
import BalanceCheck from "../components/BalanceCheck";
// import MyToken from "../data/MyToken.json";

// const provider = new ethers.providers.JsonRpcProvider(
//   process.env.HARDHAT_RPC_URL
// );
// const contract = new ethers.Contract(MyToken.address, MyToken.abi, provider);

export default function App() {
  return (
    <div className="container">
      <div className="m-5">
        <Header />
      </div>

      <div className="text-center bg-light p-5 m-5">
        <h1>My Token dApp</h1>
      </div>

      <TokenInfo />
      <TransferToken />
      <BalanceCheck />
    </div>
  );
}
